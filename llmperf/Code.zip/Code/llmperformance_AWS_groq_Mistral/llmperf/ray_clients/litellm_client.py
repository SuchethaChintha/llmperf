import time
from typing import Any, Dict
import ray
import json
from llmperf.ray_llm_client import LLMClient
from llmperf.models import RequestConfig
from llmperf import common_metrics
import os
import json
from dotenv import load_dotenv
from azure.identity import ManagedIdentityCredential,DefaultAzureCredential,ClientSecretCredential
from azure.keyvault.secrets import SecretClient
load_dotenv()

@ray.remote
class LiteLLMClient(LLMClient):
    """Client for LiteLLM Completions API."""

    def llm_request(self, request_config: RequestConfig) -> Dict[str, Any]:
        # litellm package isn't serializable, so we import it within the function
        # to maintain compatibility with ray.
        from litellm import completion, validate_environment

        prompt = request_config.prompt
        prompt, prompt_len = prompt

        message = [
            {"role": "system", "content": prompt},
            {"role": "user", "content": prompt},
        ]
        assert (
            request_config.llm_api is not None
        ), "the request config's llm_api must be set."
        # credential = DefaultAzureCredential()
        # credential = ManagedIdentityCredential()
        managed_identity_client_id=os.getenv("client_id")
        # client_id=os.getenv("client_id")
        # client_secret=os.getenv("client_secret")
        # tenant_id=os.getenv("tenant_id")

        # credential = ClientSecretCredential(client_id=client_id, client_secret=client_secret,tenant_id=tenant_id)

        credential = ManagedIdentityCredential(client_id = managed_identity_client_id)
        client = SecretClient(vault_url="https://Llmperf.vault.azure.net", credential=credential)
        with open("Models.json") as m:
            items = json.load(m)
        secret_name=items["secrets"]
        secrets = {}
        for secret_data in secret_name:
                secret_name = secret_data["name"]
                try:
                    secret = client.get_secret(secret_name)
                    secrets[secret_name] = secret.value
                except (AzureKeyVaultError) as error:
                    print(f"Error retrieving secret {secret_name}: {error}")
  
        # AWS_ACCESS_KEY_ID= secrets["AWS-ACCESS-KEY-ID"]
        # AWS_SECRET_ACCESS_KEY=secrets["AWS-SECRET-ACCESS-KEY"]
        # AWS_REGION_NAME="us-east-1"
        # GROQ_API_KEY=secrets["gorq"]
        # MISTRAL_API_KEY =secrets["MISTRAL-API-KEY"]
        # GROQ_API_KEY=os.getenv("GROQ_API_KEY")
        if request_config.llm_api == "litellm":
            model = request_config.model
        else:
            model = request_config.llm_api + "/" + request_config.model
        validation_result = validate_environment(model)
        # if validation_result["missing_keys"]:
        #     raise ValueError(
        #         f"The following environment vars weren't found but were necessary for "
        #         f"the model {request_config.model}: {validation_result['missing_keys']}"
        #     )
        body = {
            "model": model,
            "messages": message,
            "stream": True,
        }
        sampling_params = request_config.sampling_params
        body.update(sampling_params or {})

        time_to_next_token = []
        tokens_received = 0
        ttft = 0
        error_response_code = -1
        generated_text = ""
        error_msg = ""
        output_throughput = 0
        total_request_time = 0

        metrics = {}

        metrics[common_metrics.ERROR_CODE] = None
        metrics[common_metrics.ERROR_MSG] = ""
        if "bedrock" in model:
            provider="Amazon Bedrock"
        elif "groq" in model:
            provider="Groq Cloud"
        elif "mistral" in model:
            provider= "Mistral AI"
        body_content=json.dumps(body, indent=2)
        body_response=""    
        try:
            start_time = time.monotonic()
            most_recent_received_token_time = time.monotonic()

            response = completion(**body)
            ttft = 0
            for tok in response:
                if tok.choices[0].delta:
                    delta = tok.choices[0].delta
                    if delta.get("content", None):
                        if ttft == 0:
                            ttft = time.monotonic() - start_time
                            time_to_next_token.append(ttft)
                        else:
                            time_to_next_token.append(
                                time.monotonic() - most_recent_received_token_time
                            )
                        generated_text += delta["content"]
                        most_recent_received_token_time = time.monotonic()
                        tokens_received += 1
                        body_response=generated_text

            total_request_time = time.monotonic() - start_time

            output_throughput = tokens_received / total_request_time

        except Exception as e:
            metrics[common_metrics.ERROR_MSG] = error_msg
            metrics[common_metrics.ERROR_CODE] = error_response_code

            print(f"Warning Or Error: {e}")
            print(error_response_code)
        
        metrics[common_metrics.INTER_TOKEN_LAT] = sum(time_to_next_token)
        metrics[common_metrics.TTFT] = ttft
        metrics[common_metrics.E2E_LAT] = total_request_time
        metrics[common_metrics.REQ_OUTPUT_THROUGHPUT] = output_throughput
        metrics[common_metrics.NUM_TOTAL_TOKENS] = tokens_received + prompt_len
        metrics[common_metrics.NUM_OUTPUT_TOKENS] = tokens_received
        metrics[common_metrics.NUM_INPUT_TOKENS] = prompt_len
        metrics[common_metrics.PROVIDER_PLATFORM]=provider
        metrics[common_metrics.REQUEST]=body_content
        metrics[common_metrics.RESPONSE]=body_response
        return metrics, generated_text, request_config
